﻿using CopyDirectoryBusiness.Constants;
using CopyDirectoryBusiness.Logging;
using CopyDirectoryBusiness.Model;
using Microsoft.VisualBasic.FileIO;
using System;
using System.IO;
using System.Linq;
using System.Reflection;

namespace CopyDirectoryBusiness.BusinessLogic
{
    public class CopyDirectoryBusinessLogic : ICopyDirectoryBusinessLogic
    {
        Logger _logger;

        public CopyDirectoryBusinessLogic() => _logger = new Logger();

        /// <summary>
        /// Copies files/Folders from Source Directory to destination directory
        /// </summary>
        /// <param name="copyDirectoryRequest"><see cref="CopyDirectoryRequest"/></param>
        /// <returns><see cref="CopyDirectoryResponse"/></returns>
        public CopyDirectoryResponse CopyDirectory(CopyDirectoryRequest copyDirectoryRequest)
        {
            _logger.Info($"Entering {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

            try
            {
                CopyDirectoryResponse _copyDirectoryResponse = null;

                _copyDirectoryResponse = ValidateCopyDirectoryRequest(copyDirectoryRequest);

                if (_copyDirectoryResponse != null && _copyDirectoryResponse.Success)
                {
                    FileSystem.CopyDirectory(copyDirectoryRequest.SourcePath, copyDirectoryRequest.DestinationPath, UIOption.AllDialogs);

                    _logger.Info($"Exiting {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

                    return BuildCopyDirectoryResponse(true, GlobalConstants.Success_Message);
                }
                else
                {
                    _logger.Info($"Exiting {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

                    return _copyDirectoryResponse;
                }
            }
            catch(Exception ex)
            {
                _logger.Error($"Exception while copying files. Exception details {ex.Message}");
                _logger.Error($"Exception while copying files. Inner Exception {ex.InnerException}");

                _logger.Info($"Exiting {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

                return BuildCopyDirectoryResponse(false, GlobalConstants.Error_Others);
            }
        }

        /// <summary>
        /// Validates <see cref="CopyDirectoryRequest"/> has valid input data
        /// </summary>
        /// <param name="copyDirectoryRequest"><see cref="CopyDirectoryRequest"/></param>
        /// <returns><see cref="CopyDirectoryResponse"/></returns>
        private CopyDirectoryResponse ValidateCopyDirectoryRequest(CopyDirectoryRequest copyDirectoryRequest)
        {
            _logger.Info($"Entering {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

            if (string.IsNullOrEmpty(copyDirectoryRequest.SourcePath))
            {
                _logger.Info($"Exiting {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

                return BuildCopyDirectoryResponse(false, GlobalConstants.Error_Invalid_Source_Path);
            }
            else if(string.IsNullOrEmpty(copyDirectoryRequest.DestinationPath))
            {
                _logger.Info($"Exiting {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

                return BuildCopyDirectoryResponse(false, GlobalConstants.Error_Invalid_Destination_Path);
            }
            else
            {
                var sourceDirectories = Directory.GetDirectories(copyDirectoryRequest.SourcePath);
                var sourceFiles = Directory.GetFiles(copyDirectoryRequest.SourcePath);
                bool hasFilesinSource = sourceFiles != null && sourceFiles.Any();
                bool hasDirectoryinSource = sourceDirectories != null && sourceDirectories.Any();

                if(hasFilesinSource || hasDirectoryinSource)
                {
                    _logger.Info($"Exiting {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

                    return BuildCopyDirectoryResponse(true, null);
                }
                else
                {
                    _logger.Info($"Exiting {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

                    return BuildCopyDirectoryResponse(false, GlobalConstants.Error_Empty_Source_Path);
                }
            }
        }

        /// <summary>
        /// Builds <see cref="CopyDirectoryResponse"/> object
        /// </summary>
        /// <param name="success">Success or failure response</param>
        /// <param name="message">Success or Failure Message</param>
        /// <returns><see cref="CopyDirectoryResponse"/></returns>
        private CopyDirectoryResponse BuildCopyDirectoryResponse(bool success, string message)
        {
            return new CopyDirectoryResponse()
            {
                Success = success,
                Message = message
            };
        }
    }
}
