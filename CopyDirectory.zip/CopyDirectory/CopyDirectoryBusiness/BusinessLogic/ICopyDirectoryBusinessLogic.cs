﻿using CopyDirectoryBusiness.Model;

namespace CopyDirectoryBusiness.BusinessLogic
{
    interface ICopyDirectoryBusinessLogic
    {
        public CopyDirectoryResponse CopyDirectory(CopyDirectoryRequest copyDirectoryRequest);
    }
}
