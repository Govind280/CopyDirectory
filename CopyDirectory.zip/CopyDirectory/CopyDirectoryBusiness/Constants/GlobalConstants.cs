﻿namespace CopyDirectoryBusiness.Constants
{
    public static class GlobalConstants
    {
        public const string Success_Message = "Files and/or Directories Copied Successfully!!! To redo Directory Copy, Please select Source and Destination again!!!";

        public const string Error_Invalid_Source_Path = "Error : Source Path Doesn't exist!!!";

        public const string Error_Invalid_Destination_Path = "Error : Destination Path Doesn't exist!!!";

        public const string Error_Empty_Source_Path = "Error : Source Path doesn't have Files or Directories. Please select valid Source Directory!!!";
        
        public const string Error_Others = "There is error in copying Files/Directories. Please constact Administrator!!!";
    }
}
