﻿using log4net;
using log4net.Config;
using System.IO;
using System.Reflection;

namespace CopyDirectoryBusiness.Logging
{
    public class Logger //: ILogger
    {
        private readonly ILog _logger = null;

        public Logger():this(LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType))
        {
            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));
        }

        public Logger(ILog logger)
        {
            _logger = logger;
        }

        public void Debug(string message)
        {
            _logger.Debug(message);
        }

        public void Info(string message)
        {
            _logger.Info(message);
        }

        public void Error(string message)
        {
            _logger.Error(message);
        }
    }
}
