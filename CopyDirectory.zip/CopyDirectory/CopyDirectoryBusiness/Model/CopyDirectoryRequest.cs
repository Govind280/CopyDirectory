﻿namespace CopyDirectoryBusiness.Model
{
    public class CopyDirectoryRequest
    {
        public string SourcePath;

        public string DestinationPath;
    }
}
