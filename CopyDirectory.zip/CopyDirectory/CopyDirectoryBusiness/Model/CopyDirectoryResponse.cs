﻿namespace CopyDirectoryBusiness.Model
{
    public class CopyDirectoryResponse
    {
        public bool Success;

        public string Message;
    }
}
