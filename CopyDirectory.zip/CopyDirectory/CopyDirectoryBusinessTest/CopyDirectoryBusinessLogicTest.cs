using NUnit.Framework;
using CopyDirectoryBusiness.BusinessLogic;
using CopyDirectoryBusiness.Constants;
using CopyDirectoryBusiness.Model;

namespace CopyDirectoryBusinessTest
{
    public class CopyDirectoryBusinessLogicTests
    {
        CopyDirectoryRequest _copyDirectoryRequest = null;
        CopyDirectoryResponse _expectedCopyDirectoryResponse = null;
        CopyDirectoryBusinessLogic _copyDirectoryBusinessLogic = null;        

        [SetUp]
        public void Setup()
        {
            _copyDirectoryRequest = new CopyDirectoryRequest()
            {
                SourcePath = "../../../Source",
                DestinationPath = "../../../Destination"
            };

            _copyDirectoryBusinessLogic = new CopyDirectoryBusinessLogic();

            _expectedCopyDirectoryResponse = new CopyDirectoryResponse()
            {
                Success = false,
                Message = ""
            };
        }

        [Test]
        public void Test_CopyDirectory_Success()
        {
            _expectedCopyDirectoryResponse.Success = true;
            _expectedCopyDirectoryResponse.Message = GlobalConstants.Success_Message;

            CopyDirectoryResponse _actualResponse = _copyDirectoryBusinessLogic.CopyDirectory(_copyDirectoryRequest);

            Assert.AreEqual(_expectedCopyDirectoryResponse.Success, _actualResponse.Success);
            Assert.AreEqual(_expectedCopyDirectoryResponse.Message, _actualResponse.Message);
        }

        [Test]
        public void Test_CopyDirectory_Failure_EmptySourceString()
        {
            _copyDirectoryRequest.SourcePath = null;
            _expectedCopyDirectoryResponse.Message = GlobalConstants.Error_Invalid_Source_Path;

            CopyDirectoryResponse _actualResponse = _copyDirectoryBusinessLogic.CopyDirectory(_copyDirectoryRequest);

            Assert.AreEqual(_expectedCopyDirectoryResponse.Success, _actualResponse.Success);
            Assert.AreEqual(_expectedCopyDirectoryResponse.Message, _actualResponse.Message);
        }

        [Test]
        public void Test_CopyDirectory_Failure_EmptyDestinationString()
        {
            _copyDirectoryRequest.DestinationPath = null;
            _expectedCopyDirectoryResponse.Message = GlobalConstants.Error_Invalid_Destination_Path;

            CopyDirectoryResponse _actualResponse = _copyDirectoryBusinessLogic.CopyDirectory(_copyDirectoryRequest);

            Assert.AreEqual(_expectedCopyDirectoryResponse.Success, _actualResponse.Success);
            Assert.AreEqual(_expectedCopyDirectoryResponse.Message, _actualResponse.Message);
        }

        [Test]
        public void Test_CopyDirectory_Failure_EmptySourceFolder()
        {
            _copyDirectoryRequest.SourcePath = "../../../Source_Empty";
            _expectedCopyDirectoryResponse.Message = GlobalConstants.Error_Empty_Source_Path;

            CopyDirectoryResponse _actualResponse = _copyDirectoryBusinessLogic.CopyDirectory(_copyDirectoryRequest);

            Assert.AreEqual(_expectedCopyDirectoryResponse.Success, _actualResponse.Success);
            Assert.AreEqual(_expectedCopyDirectoryResponse.Message, _actualResponse.Message);
        }

        [Test]
        public void Test_CopyDirectory_Failure_ExceptionHandling()
        {
            _copyDirectoryRequest.SourcePath = "../Source_Empty";
            _expectedCopyDirectoryResponse.Message = GlobalConstants.Error_Others;

            CopyDirectoryResponse _actualResponse = _copyDirectoryBusinessLogic.CopyDirectory(_copyDirectoryRequest);

            Assert.AreEqual(_expectedCopyDirectoryResponse.Success, _actualResponse.Success);
            Assert.AreEqual(_expectedCopyDirectoryResponse.Message, _actualResponse.Message);
        }
    }
}