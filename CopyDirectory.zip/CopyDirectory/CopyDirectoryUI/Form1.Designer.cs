﻿using CopyDirectoryBusiness.Logging;

namespace CopyDirectoryUI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCopyDireactoryHeading = new System.Windows.Forms.Label();
            this.btnSelectSource = new System.Windows.Forms.Button();
            this.lstSourceFolderContents = new System.Windows.Forms.ListBox();
            this.btnSelectDestination = new System.Windows.Forms.Button();
            this.lstDestinationFolderContents = new System.Windows.Forms.ListBox();
            this.btnCopyFiles = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.SuspendLayout();
            // 
            // lblCopyDireactoryHeading
            // 
            this.lblCopyDireactoryHeading.AutoSize = true;
            this.lblCopyDireactoryHeading.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblCopyDireactoryHeading.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCopyDireactoryHeading.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lblCopyDireactoryHeading.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCopyDireactoryHeading.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblCopyDireactoryHeading.Location = new System.Drawing.Point(350, 45);
            this.lblCopyDireactoryHeading.Name = "lblCopyDireactoryHeading";
            this.lblCopyDireactoryHeading.Size = new System.Drawing.Size(560, 37);
            this.lblCopyDireactoryHeading.TabIndex = 0;
            this.lblCopyDireactoryHeading.Text = "Welcome to Copy Directory to Copy your Files";
            this.lblCopyDireactoryHeading.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSelectSource
            // 
            this.btnSelectSource.Location = new System.Drawing.Point(91, 174);
            this.btnSelectSource.Name = "btnSelectSource";
            this.btnSelectSource.Size = new System.Drawing.Size(218, 29);
            this.btnSelectSource.TabIndex = 1;
            this.btnSelectSource.Text = "Select Source Folder";
            this.btnSelectSource.UseVisualStyleBackColor = true;
            this.btnSelectSource.Click += new System.EventHandler(this.btnSelectSourceFolder_Click);
            // 
            // lstSourceFolderContents
            // 
            this.lstSourceFolderContents.FormattingEnabled = true;
            this.lstSourceFolderContents.ItemHeight = 20;
            this.lstSourceFolderContents.Location = new System.Drawing.Point(91, 275);
            this.lstSourceFolderContents.Name = "lstSourceFolderContents";
            this.lstSourceFolderContents.Size = new System.Drawing.Size(456, 324);
            this.lstSourceFolderContents.TabIndex = 2;
            // 
            // btnSelectDestination
            // 
            this.btnSelectDestination.Location = new System.Drawing.Point(691, 173);
            this.btnSelectDestination.Name = "btnSelectDestination";
            this.btnSelectDestination.Size = new System.Drawing.Size(228, 29);
            this.btnSelectDestination.TabIndex = 3;
            this.btnSelectDestination.Text = "Select Destination Folder";
            this.btnSelectDestination.UseVisualStyleBackColor = true;
            this.btnSelectDestination.Click += new System.EventHandler(this.btnSelectDestinationFolder_Click);
            // 
            // lstDestinationFolderContents
            // 
            this.lstDestinationFolderContents.FormattingEnabled = true;
            this.lstDestinationFolderContents.ItemHeight = 20;
            this.lstDestinationFolderContents.Location = new System.Drawing.Point(691, 275);
            this.lstDestinationFolderContents.Name = "lstDestinationFolderContents";
            this.lstDestinationFolderContents.Size = new System.Drawing.Size(519, 324);
            this.lstDestinationFolderContents.TabIndex = 4;
            // 
            // btnCopyFiles
            // 
            this.btnCopyFiles.Location = new System.Drawing.Point(574, 655);
            this.btnCopyFiles.Name = "btnCopyFiles";
            this.btnCopyFiles.Size = new System.Drawing.Size(94, 29);
            this.btnCopyFiles.TabIndex = 5;
            this.btnCopyFiles.Text = "Copy Files";
            this.btnCopyFiles.UseVisualStyleBackColor = true;
            this.btnCopyFiles.Click += new System.EventHandler(this.btnCopyFiles_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1355, 722);
            this.Controls.Add(this.btnCopyFiles);
            this.Controls.Add(this.lstDestinationFolderContents);
            this.Controls.Add(this.btnSelectDestination);
            this.Controls.Add(this.lstSourceFolderContents);
            this.Controls.Add(this.btnSelectSource);
            this.Controls.Add(this.lblCopyDireactoryHeading);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCopyDireactoryHeading;
        private System.Windows.Forms.Button btnSelectSource;
        private System.Windows.Forms.ListBox lstSourceFolderContents;
        private System.Windows.Forms.Button btnSelectDestination;
        private System.Windows.Forms.ListBox lstDestinationFolderContents;
        private System.Windows.Forms.Button btnCopyFiles;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
    }
}

