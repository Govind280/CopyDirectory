﻿using CopyDirectoryBusiness.BusinessLogic;
using CopyDirectoryBusiness.Logging;
using CopyDirectoryBusiness.Model;
using System.Reflection;
using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace CopyDirectoryUI
{
    public partial class Form1 : Form
    {
        private string sourcePath = string.Empty;
        private string destinationPath = string.Empty;
        Logger _logger = new Logger();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSelectSourceFolder_Click(object sender, EventArgs e)
        {
            _logger.Info($"Entering {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

            sourcePath = string.Empty;
            folderBrowserDialog1.ShowDialog();
            sourcePath = folderBrowserDialog1.SelectedPath;

            PopulateListBoxWithFileDetails(sourcePath, lstSourceFolderContents);

            _logger.Info($"Exiting {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");
        }

        private void btnSelectDestinationFolder_Click(object sender, EventArgs e)
        {
            _logger.Info($"Entering {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

            destinationPath = string.Empty;
            folderBrowserDialog1.ShowDialog();
            destinationPath = folderBrowserDialog1.SelectedPath;

            _logger.Info($"Exiting {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");
        }

        private void btnCopyFiles_Click(object sender, EventArgs e)
        {
            _logger.Info($"Entering {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

            try
            {
                // Build request for business Layer
                CopyDirectoryRequest _copyDirectoryRequest = new CopyDirectoryRequest()
                {
                    SourcePath = sourcePath,
                    DestinationPath = destinationPath
                };

                CopyDirectoryBusinessLogic _copyDirectoryBusiness = new CopyDirectoryBusinessLogic();

                CopyDirectoryResponse _copyDirectoryResponse = _copyDirectoryBusiness.CopyDirectory(_copyDirectoryRequest);

                DialogResult _dialogResult = MessageBox.Show(
                    _copyDirectoryResponse.Message,
                    "Copy Directory Response",
                    MessageBoxButtons.OK,
                    _copyDirectoryResponse.Success ? MessageBoxIcon.Information : MessageBoxIcon.Error);

                if(_dialogResult == DialogResult.OK)
                {
                    PopulateListBoxWithFileDetails(destinationPath, lstDestinationFolderContents);
                }

                sourcePath = destinationPath = null;
            }
            catch(Exception ex)
            {
                _logger.Error("Exception while Copying files. Please read inner exceptionf ro more details.");
                _logger.Error($"Inner Exception {ex.InnerException}");
            }

            _logger.Info($"Exiting {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");
        }

        private void PopulateListBoxWithFileDetails(string folderPath, ListBox lstFolderContents)
        {
            _logger.Info($"Entering {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");

            var sourceFolderDirectories = Directory.GetDirectories(folderPath);
            var sourceFolderFiles = Directory.GetFiles(folderPath);
            bool hasFilesinSource = sourceFolderFiles != null && sourceFolderFiles.Any();
            bool hasDirectoryinSource = sourceFolderDirectories != null && sourceFolderDirectories.Any();

            if (hasFilesinSource || hasDirectoryinSource)
            {
                lstFolderContents.Items.Clear();
                if (hasFilesinSource)
                {
                    foreach (string fileLocation in sourceFolderFiles)
                    {
                        lstFolderContents.Items.Add(fileLocation);
                    }
                }

                if (hasDirectoryinSource)
                {
                    foreach (string folderLocation in sourceFolderDirectories)
                    {
                        lstFolderContents.Items.Add(folderLocation);
                    }
                }
            }

            _logger.Info($"Exiting {this.GetType().FullName}.{MethodBase.GetCurrentMethod().Name} Method...");
        }
    }
}
